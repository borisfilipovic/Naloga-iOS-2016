//
//  MatchPitchProtocol.swift
//  KLIKA iOS Naloga 2016
//
//  Created by Boris Filipovic on 29/05/16.
//  Copyright © 2016 Boris Filipovic. All rights reserved.
//

import Foundation

protocol MatchPitchProtocol {
    func setResultForHome(home:NSNumber?, andAway:NSNumber?)
}
